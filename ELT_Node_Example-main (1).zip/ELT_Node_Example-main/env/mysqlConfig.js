const config = {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'etl'
};

module.exports = config;