const express = require("express");
const router = express.Router();
const etlDao = require("../dao/etl.dao")

router.get('/fill-firebase', etlDao.fillFirebase);
router.get('/etl-process', etlDao.EtlProcess);

module.exports = router;