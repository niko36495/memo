// Post Elements
const uploadBtn = document.getElementById("uploadBtn");
const processBtn = document.getElementById("processBtn");

uploadBtn.addEventListener('click', async function () {
    try {
        const response = await fetch('/etl/fill-firebase');
        const message = await response.text();
        console.log(message);
    } catch (error) {
        console.error('Error:', error);
    }
});

processBtn.addEventListener('click', async function () {
    try {
        const response = await fetch('/etl/etl-process');
        const message = await response.text();
        console.log(message);
    } catch (error) {
        console.error('Error:', error);
    }
});
