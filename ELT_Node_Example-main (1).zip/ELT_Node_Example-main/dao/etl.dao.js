const mysql = require('../services/mysql.service');
const firebase = require('../services/firebase.service')

const fillFirebase = async (req, res) => {
  try {
    const data = [
      { "Name": "Sergio", "Age": 26, "Jobs": ["Engineer", "Teacher", "Developer"] },
      { "Name": "Roy", "Age": 36, "Jobs": ["Engineer", "Teacher", "Pilot"] },
      { "Name": "Pepe", "Age": 27, "Jobs": ["Engineer", "UI/UX", "Developer"] }
    ];

    for (const student of data) {
      await firebase.collection("Student").add(student);
    }

    res.status(201).json({ message: "Data succesfully created in firebase" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const EtlProcess = async (req, res) => {
  try {
    const snapshot = await firebase.collection("Student").get();
    const rows = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    for (const row of rows) {
      await mysql.query(
        'INSERT INTO student (id, name, age) VALUES (?, ?, ?)',
        [row.id, row.Name, row.Age]
      );

      for (const job of row.Jobs) {
        // SELECT id FROM job WHERE name = job;
        await mysql.query(
          'INSERT INTO job (student_id, name) VALUES (?, ?)',
          [row.id, job]
        );
      }
    }
    res.status(200).json({ message: "Process completed succesfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { EtlProcess, fillFirebase };