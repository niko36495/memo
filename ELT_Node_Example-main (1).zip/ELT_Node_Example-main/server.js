const express = require("express");
const etlRoutes = require("./routes/etl.routes");

const PORT = 5000;
const api = express();

api.use(express.json());
api.use(express.static("public"));

api.use("/etl", etlRoutes);

api.listen(PORT, ()=>{
    console.log("Server running in http://localhost:5000")
});